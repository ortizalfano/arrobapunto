=== xprojects ===
Contributors: (arrobapunto)
Tags: projects, project management, tasks, task manager, client portal, jira, asana, trello
Requires at least: 5.8
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

La forma más sencilla y elegante de gestionar tus proyectos, tareas y clientes directamente desde tu panel de WordPress.

== Description ==

¿Cansado de gestionar proyectos con hojas de cálculo interminables y cadenas de correos caóticas? Projects integra un potente y visual gestor de proyectos directamente en tu entorno de WordPress. Diseñado para freelancers, agencias y equipos que valoran la eficiencia y un diseño limpio, nuestro plugin te permite tener el control total de tu flujo de trabajo sin salir de tu sitio web.

Desde la creación de proyectos hasta el seguimiento del progreso con gráficos interactivos, Projects transforma tu WordPress en un centro de mando centralizado.

¿Por qué elegir Projects?

✅ Todo en un solo lugar: Olvídate de cambiar entre diferentes aplicaciones. Gestiona tus proyectos y tareas directamente desde WordPress.

🚀 Portal de Cliente Profesional: Ofrece a tus clientes un portal de marca blanca con una página de acceso personalizada para que puedan seguir el avance de sus proyectos. ¡Adiós al wp-login.php!

🎨 Diseño Intuitivo y Elegante: Inspirado en las mejores herramientas de gestión y con una estética limpia al estilo Apple, la interfaz es potente pero increíblemente fácil de usar.

🔌 Plug and Play: ¡Activa el plugin y listo! Las páginas del portal se crean automáticamente, sin configuraciones complejas.

📊 Visualiza tu Progreso: Con gráficos y barras de avance, obtén una visión clara del estado de todos tus proyectos de un solo vistazo.

== Installation ==

Sube la carpeta projects al directorio /wp-content/plugins/.

Activa el plugin a través del menú 'Plugins' en WordPress.

¡Listo! El plugin habrá creado automáticamente dos nuevas páginas: "Portal de Proyectos" y "Acceso al Portal".

Ve a Apariencia > Menús y añade la página "Portal de Proyectos" a tu menú principal para un acceso fácil.

Ve al nuevo menú "Projects" en tu panel de administración para empezar a crear tu primer proyecto.

== Frequently Asked Questions ==

¿Necesito crear las páginas del portal manualmente?
No. Projects es "Plug and Play". Al activarlo, crea automáticamente la página del "Portal de Proyectos" y una página de "Acceso al Portal" personalizada para tus usuarios.

¿Mis clientes pueden ver los proyectos de otros clientes?
En esta versión gratuita, todos los proyectos son gestionados por los usuarios administradores. Para una gestión avanzada de permisos y roles de cliente, considera nuestra futura versión Pro.

¿El diseño se adaptará a mi tema?
Sí. Hemos diseñado el portal para que se integre de la forma más limpia posible con cualquier tema de WordPress.

¿Puedo asignar tareas a otros usuarios?
En la versión actual, las tareas son gestionadas por el usuario que las crea. La asignación de tareas a usuarios específicos es una de las funcionalidades clave de nuestra próxima versión Pro.

== Screenshots ==

Dashboard Principal: Una vista general del dashboard, mostrando la tabla de proyectos, la nueva tabla de tareas pendientes y los gráficos laterales.

Página de Proyecto Individual: La vista detallada de un proyecto, con el botón de volver, las pestañas de "Tareas Pendientes" y "Tareas Terminadas", y la tabla de tareas.

Modal de Añadir Tarea: El elegante popup para crear una nueva tarea, con todos sus campos.

Página de Acceso Personalizada: Una captura de la página tuweb.com/acceso-al-portal/ para mostrar la experiencia de login profesional.

Backend del Plugin: Una vista del menú "Projects" en el panel de administración de WordPress.

== Changelog ==

= 1.0.0 =

¡Lanzamiento inicial del plugin!

== Upgrade Notice ==

= 1.0.0 =

Esta es la primera versión de Projects. ¡Gracias por usarlo!

== ⭐ Próximamente: Projects Pro ==

Estamos llevando la gestión de proyectos al siguiente nivel con funcionalidades para equipos profesionales:

Vista de Tablero Kanban: Arrastra y suelta tareas entre columnas de estado.

Roles de Cliente y Equipo: Control de permisos granular para que tus clientes solo vean sus proyectos.

Asignación de Tareas a Usuarios: Asigna tareas a miembros específicos de tu equipo y controla la carga de trabajo.

Comentarios y Notificaciones: Centraliza toda la comunicación con comentarios en cada tarea y recibe notificaciones por correo electrónico.

Reportes y Exportación: Genera informes de tiempo y exporta tus datos a PDF/CSV.

¡Y mucho más!