<?php
/**
 * The template for displaying a single Project.
 * This template is loaded via the template-loader.php file.
 */

get_header(); ?>

<div id="primary" class="content-area project-single-page">
    <main id="main" class="site-main">

        <?php while ( have_posts() ) : the_post(); ?>

            <div class="single-project-container" data-project-id="<?php echo get_the_ID(); ?>">
                <header class="project-header">
                    <a href="<?php echo esc_url( get_permalink( get_option('projects_portal_page_id') ) ); ?>" id="back-to-dashboard-btn" class="button">&larr; <?php _e('Volver a Proyectos', 'projects'); ?></a>
                    <h1 class="project-title"><?php the_title(); ?></h1>
                </header>
                
                <div class="project-main-content">
                    <?php the_content(); ?>
                </div>

                <div class="project-tasks-area">
                    <div class="tasks-tabs">
                        <span class="tab-item active" data-filter="active"><?php _e('Tareas Pendientes', 'projects'); ?></span>
                        <span class="tab-item" data-filter="completed"><?php _e('Tareas Terminadas', 'projects'); ?></span>
                    </div>
                    <div class="widget-box">
                        <div class="widget-box-header">
                            <h3><?php _e('Lista de Tareas', 'projects'); ?></h3>
                            <button id="add-task-btn" class="button button-primary"><?php _e('Añadir Tarea', 'projects'); ?></button>
                        </div>
                        <div class="widget-box-content">
                            <div id="tasks-table-container">
                                 <!-- La tabla de tareas se cargará aquí vía AJAX -->
                                <div class="spinner-container"><span class="spinner is-active"></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php endwhile; // End of the loop. ?>

    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
