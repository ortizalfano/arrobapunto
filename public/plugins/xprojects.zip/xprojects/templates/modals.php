<?php
/**
 * Template for all modals used in the Projects plugin.
 * This file is included in the footer via a hook in the main plugin class.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<!-- =================================================================== -->
<!-- Modal para Añadir Proyecto -->
<!-- =================================================================== -->
<div id="add-project-modal" class="project-modal-overlay">
    <div class="project-modal-content">
        <form id="add-project-form">
            <h3><?php _e('Crear Nuevo Proyecto', 'projects'); ?></h3>
            <div class="form-row">
                <label for="new_project_title"><?php _e('Nombre de Proyecto', 'projects'); ?>*</label>
                <input type="text" id="new_project_title" name="new_project_title" required>
            </div>
            <div class="form-row">
                <label for="new_project_content"><?php _e('Descripción', 'projects'); ?>*</label>
                <textarea id="new_project_content" name="new_project_content" rows="3" required></textarea>
            </div>
            <div class="form-row-split">
                <div class="form-row">
                    <label for="new_project_start_date"><?php _e('Fecha de Inicio', 'projects'); ?>*</label>
                    <input type="date" id="new_project_start_date" name="new_project_start_date" required>
                </div>
                <div class="form-row">
                    <label for="new_project_end_date"><?php _e('Fecha Fin', 'projects'); ?>*</label>
                    <input type="date" id="new_project_end_date" name="new_project_end_date" required>
                </div>
            </div>
            <div class="form-row">
                <label><?php _e('Prioridad', 'projects'); ?></label>
                <div class="priority-selector" id="project-priority-selector">
                    <input type="hidden" id="new_project_priority" name="new_project_priority">
                    <?php 
                    $priorities = get_terms(['taxonomy' => 'project_priority', 'hide_empty' => false, 'orderby' => 'id', 'order' => 'DESC']);
                    if (!is_wp_error($priorities) && !empty($priorities)) {
                        foreach($priorities as $priority) {
                            $is_active = (strtolower($priority->name) === 'media') ? 'active' : '';
                            echo '<span class="priority-option '.$is_active.'" data-value="'.$priority->term_id.'">'.esc_html($priority->name).'</span>';
                        }
                    }
                    ?>
                </div>
            </div>
            <div class="form-row">
                <label for="new_project_tags"><?php _e('Etiquetas', 'projects'); ?></label>
                <input type="text" id="new_project_tags" name="new_project_tags" placeholder="<?php _e('ej: diseño, marketing', 'projects'); ?>">
            </div>
            <div class="form-actions">
                <button type="submit" class="button button-primary"><?php _e('Guardar Proyecto', 'projects'); ?></button>
                <button type="button" class="button cancel-modal-btn"><?php _e('Cancelar', 'projects'); ?></button>
                <span class="spinner"></span>
            </div>
            <div class="modal-status"></div>
        </form>
    </div>
</div>


<!-- =================================================================== -->
<!-- Modal para Confirmar Eliminación -->
<!-- =================================================================== -->
<div id="delete-confirm-modal" class="project-modal-overlay">
    <div class="project-modal-content small-modal">
        <h3><?php _e('Confirmar Eliminación', 'projects'); ?></h3>
        <p><?php _e('¿Estás seguro de que quieres eliminar esto? Esta acción no se puede deshacer.', 'projects'); ?></p>
        <div class="form-actions">
            <button id="confirm-delete-btn" class="button button-danger"><?php _e('Sí, eliminar', 'projects'); ?></button>
            <button type="button" class="button cancel-modal-btn"><?php _e('Cancelar', 'projects'); ?></button>
        </div>
    </div>
</div>


<!-- =================================================================== -->
<!-- Modal para Añadir Tarea -->
<!-- =================================================================== -->
<div id="add-task-modal" class="project-modal-overlay">
    <div class="project-modal-content">
        <form id="add-task-form">
            <h3><?php _e('Añadir Nueva Tarea', 'projects'); ?></h3>
            <input type="hidden" id="parent_project_id" name="parent_project_id" value="">
            
            <div class="form-row">
                <label for="new_task_title"><?php _e('Título de la tarea', 'projects'); ?>*</label>
                <input type="text" id="new_task_title" name="new_task_title" required>
            </div>
            
            <div class="form-row">
                <label for="new_task_description"><?php _e('Descripción detallada', 'projects'); ?></label>
                <textarea id="new_task_description" name="new_task_description" rows="4"></textarea>
            </div>

            <div class="form-row-split">
                <div class="form-row">
                    <label for="new_task_start_date"><?php _e('Fecha de inicio estimada', 'projects'); ?></label>
                    <input type="date" id="new_task_start_date" name="new_task_start_date">
                </div>
                <div class="form-row">
                    <label for="new_task_end_date"><?php _e('Fecha de vencimiento', 'projects'); ?></label>
                    <input type="date" id="new_task_end_date" name="new_task_end_date">
                </div>
            </div>

            <div class="form-row-split">
                <div class="form-row">
                    <label><?php _e('Prioridad', 'projects'); ?></label>
                    <div class="priority-selector" id="task-priority-selector">
                        <input type="hidden" id="new_task_priority" name="new_task_priority">
                        <?php 
                        $priorities = get_terms(['taxonomy' => 'project_priority', 'hide_empty' => false, 'orderby' => 'id', 'order' => 'DESC']);
                        if (!is_wp_error($priorities) && !empty($priorities)) {
                            foreach($priorities as $priority) {
                                $is_active = (strtolower($priority->name) === 'media') ? 'active' : '';
                                echo '<span class="priority-option '.$is_active.'" data-value="'.$priority->term_id.'">'.esc_html($priority->name).'</span>';
                            }
                        }
                        ?>
                    </div>
                </div>
                <div class="form-row">
                    <label><?php _e('Estado inicial', 'projects'); ?></label>
                    <select id="new_task_status" name="new_task_status">
                       <?php 
                       $task_statuses = get_terms(['taxonomy' => 'task_status', 'hide_empty' => false]);
                       if (!is_wp_error($task_statuses)) {
                           foreach($task_statuses as $status) {
                               $selected = (strtolower($status->name) === 'to do') ? 'selected' : '';
                               echo '<option value="'.esc_attr($status->term_id).'" '.$selected.'>'.esc_html($status->name).'</option>';
                           }
                       }
                       ?>
                    </select>
                </div>
            </div>

            <div class="form-row-split">
                <div class="form-row">
                    <label for="new_task_tags"><?php _e('Etiquetas', 'projects'); ?></label>
                    <input type="text" id="new_task_tags" name="new_task_tags" placeholder="ej: front-end, bug">
                </div>
                <div class="form-row">
                    <label for="new_task_estimated_time"><?php _e('Tiempo estimado (horas)', 'projects'); ?></label>
                    <input type="number" id="new_task_estimated_time" name="new_task_estimated_time" min="0" step="0.5">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="button button-primary"><?php _e('Guardar Tarea', 'projects'); ?></button>
                <button type="button" class="button cancel-modal-btn"><?php _e('Cancelar', 'projects'); ?></button>
                <span class="spinner"></span>
            </div>
            <div class="modal-status"></div>
        </form>
    </div>
</div>
