<?php
/**
 * Registers all Custom Post Types and Taxonomies for the plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Projects_CPT {
    public function __construct() {
        add_action('init', [$this, 'register_post_types_and_taxonomies']);
        add_action( 'add_meta_boxes', [ $this, 'add_project_details_meta_box' ] );
        add_action( 'save_post_project', [ $this, 'save_project_details_meta_box' ] );
    }

    public function register_post_types_and_taxonomies() {
        // --- CPT: Project ---
        $project_labels = [ 
            'name' => _x( 'Projects', 'Post type general name', 'projects' ), 
            'singular_name' => _x( 'Project', 'Post type singular name', 'projects' ), 
            'menu_name' => _x( 'Projects', 'Admin Menu text', 'projects' ), 
            'all_items' => __( 'All Projects', 'projects' ), 
            'add_new_item' => __( 'Add New Project', 'projects' ) 
        ];
        $project_args = [ 
            'labels' => $project_labels, 
            'public' => true, 
            'show_ui' => true, 
            'show_in_menu' => true, 
            'rewrite' => [ 'slug' => 'project' ], 
            'capability_type' => 'post', 
            'has_archive' => true, 
            'menu_position' => 20, 
            'supports' => [ 'title', 'editor', 'thumbnail', 'comments', 'author' ], 
            'menu_icon' => 'dashicons-portfolio' 
        ];
        register_post_type( 'project', $project_args );

        // --- CPT: Task (Sub-item of Project) ---
        $task_labels = [ 
            'name' => _x('Tareas', 'Post type general name', 'projects'), 
            'singular_name' => _x('Tarea', 'Post type singular name', 'projects') 
        ];
        $task_args = [
            'labels'        => $task_labels,
            'public'        => true,
            'show_ui'       => true,
            'show_in_menu'  => 'edit.php?post_type=project', // Anida las tareas bajo el menú de Proyectos
            'hierarchical'  => true, // Permite subtareas (tareas padre/hijo)
            'supports'      => ['title', 'editor', 'author', 'parent'],
            'rewrite'       => ['slug' => 'task']
        ];
        register_post_type('task', $task_args);

        // --- Taxonomies for Projects & Tasks ---
        register_taxonomy('project_status', ['project'], ['hierarchical' => true, 'label' => 'Estado del Proyecto', 'show_admin_column' => true, 'rewrite' => ['slug' => 'project-status']]);
        register_taxonomy('project_priority', ['project', 'task'], ['hierarchical' => true, 'label' => 'Prioridad', 'show_admin_column' => true, 'rewrite' => ['slug' => 'project-priority']]);
        register_taxonomy('project_tag', ['project', 'task'], ['hierarchical' => false, 'label' => 'Etiquetas', 'show_admin_column' => true, 'rewrite' => ['slug' => 'project-tag']]);
        
        // --- Taxonomies for Tasks only ---
        register_taxonomy('task_status', 'task', ['hierarchical' => true, 'label' => 'Estado de Tarea', 'show_admin_column' => true, 'rewrite' => ['slug' => 'task-status']]);
    }
    
    public function register_default_terms() {
        $project_statuses = [ 'Pending', 'In Progress', 'QA - Tests', 'In Review', 'Completed' ];
        foreach ($project_statuses as $status) { 
            if (!term_exists($status, 'project_status')) wp_insert_term($status, 'project_status'); 
        }

        $priorities = [ 'Baja', 'Media', 'Alta' ];
        foreach ($priorities as $priority) { 
            if (!term_exists($priority, 'project_priority')) wp_insert_term($priority, 'project_priority'); 
        }
        
        $task_statuses = ['To Do', 'In Progress', 'Done'];
        foreach ($task_statuses as $status) { 
            if (!term_exists($status, 'task_status')) wp_insert_term($status, 'task_status'); 
        }
    }
    
    public function add_project_details_meta_box(){
        add_meta_box('project_details_mb', 'Detalles del Proyecto', [$this, 'render_project_meta_box'], 'project', 'side', 'high');
    }
    
    public function render_project_meta_box($post){
        wp_nonce_field('save_project_meta', 'project_meta_nonce');
        $responsable = get_post_meta($post->ID, '_project_responsable_id', true);
        $start_date = get_post_meta($post->ID, '_project_start_date', true);
        $end_date = get_post_meta($post->ID, '_project_end_date', true);
        ?>
        <p>
            <label><strong><?php _e('Responsable:', 'projects'); ?></strong></label><br>
            <?php wp_dropdown_users([
                'name'             => 'project_responsable',
                'id'               => 'project_responsable',
                'show_option_none' => '— Sin asignar —',
                'selected'         => $responsable,
                'class'            => 'widefat',
            ]); ?>
        </p>
        <p>
            <label for="project_start_date"><strong><?php _e('Fecha de Inicio:', 'projects'); ?></strong></label><br>
            <input type="date" id="project_start_date" name="project_start_date" value="<?php echo esc_attr($start_date); ?>" class="widefat">
        </p>
        <p>
            <label for="project_end_date"><strong><?php _e('Fecha Fin:', 'projects'); ?></strong></label><br>
            <input type="date" id="project_end_date" name="project_end_date" value="<?php echo esc_attr($end_date); ?>" class="widefat">
        </p>
        <?php
    }

    public function save_project_details_meta_box($post_id){
        if (!isset($_POST['project_meta_nonce']) || !wp_verify_nonce($_POST['project_meta_nonce'], 'save_project_meta') || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id) || 'project' !== get_post_type($post_id)) return;
        
        if (isset($_POST['project_responsable'])) {
            update_post_meta($post_id, '_project_responsable_id', intval($_POST['project_responsable']));
        }
        if (isset($_POST['project_start_date'])) {
            update_post_meta($post_id, '_project_start_date', sanitize_text_field($_POST['project_start_date']));
        }
        if (isset($_POST['project_end_date'])) {
            update_post_meta($post_id, '_project_end_date', sanitize_text_field($_POST['project_end_date']));
        }
    }
}
