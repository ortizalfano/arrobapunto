<?php
/**
 * Handles loading the custom template for the single project view.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Projects_Template_Loader {
    public function __construct() {
        add_filter('single_template', [$this, 'load_project_template']);
    }

    /**
     * Checks if we are on a single 'project' page and loads our custom template.
     *
     * @param string $template The path of the template to include.
     * @return string The path of the template to include.
     */
    public function load_project_template($template) {
        global $post;

        // Is this a single post and is the post of type 'project'?
        if ( is_singular('project') ) {
            // Check if a 'single-project.php' file exists in the current theme.
            // This allows a theme to override our template if needed.
            $theme_template = locate_template(['single-project.php']);
            if ( $theme_template ) {
                return $theme_template;
            }

            // If the theme doesn't have a custom template, use ours.
            return PROJECTS_PLUGIN_PATH . 'templates/single-project-template.php';
        }

        return $template;
    }
}
new Projects_Template_Loader();
