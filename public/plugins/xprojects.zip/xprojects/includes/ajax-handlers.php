<?php
/**
 * Handles all AJAX requests for the frontend dashboard and project pages.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Projects_Ajax_Handlers {
    public function __construct() {
        // Register all AJAX hooks for logged-in users
        add_action( 'wp_ajax_get_project_dashboard_data', [ $this, 'ajax_get_project_dashboard_data' ] );
        add_action( 'wp_ajax_get_project_tasks', [ $this, 'ajax_get_project_tasks' ] );
        add_action( 'wp_ajax_create_new_project', [ $this, 'ajax_create_new_project' ] );
        add_action( 'wp_ajax_update_project_status', [ $this, 'ajax_update_project_status' ] );
        add_action( 'wp_ajax_delete_project', [ $this, 'ajax_delete_project' ] );
        add_action( 'wp_ajax_create_new_task', [ $this, 'ajax_create_new_task' ] );
        add_action( 'wp_ajax_update_task_status', [ $this, 'ajax_update_task_status' ] );
        add_action( 'wp_ajax_delete_task', [ $this, 'ajax_delete_task' ] );
    }

    /**
     * Gets all data needed for the main projects dashboard.
     */
    public function ajax_get_project_dashboard_data() {
        check_ajax_referer( 'projects-frontend-nonce', 'nonce' );
        
        $projects_query = new WP_Query(['post_type' => 'project', 'posts_per_page' => -1, 'post_status' => 'publish']);
        $all_projects = $projects_query->posts;

        // Data for Status Chart
        $statuses = get_terms(['taxonomy' => 'project_status', 'hide_empty' => false]);
        $status_labels = []; $status_data = []; $status_projects = [];
        $status_colors = ['#636e72', '#fdcb6e', '#0984e3', '#00cec9', '#00b894', '#fab1a0'];
        
        foreach($statuses as $index => $status) {
            $status_labels[] = $status->name;
            $projects_in_status = [];
            foreach($all_projects as $project) { if (has_term($status->term_id, 'project_status', $project->ID)) { $projects_in_status[] = $project->post_title; } }
            $status_data[] = count($projects_in_status);
            $status_projects[] = $projects_in_status;
        }

        // Data for User Chart
        $users = get_users(['role__in' => ['editor', 'author', 'administrator']]);
        $user_labels = []; $user_data = [];
        foreach($users as $user){
            $query=new WP_Query(['post_type'=>'project','posts_per_page'=>-1, 'meta_query' => [['key' => '_project_responsable_id', 'value' => $user->ID]] ]);
            if($query->post_count > 0){ $user_labels[] = $user->display_name; $user_data[] = $query->post_count; }
        }
        
        // HTML for the main projects table
        ob_start();
        $this->render_projects_table_html();
        $projects_table_html = ob_get_clean();
        
        // HTML for the dashboard tasks table
        ob_start();
        $this->render_dashboard_tasks_table_html();
        $tasks_table_html = ob_get_clean();

        wp_send_json_success([
            'charts' => [
                'status' => ['labels' => $status_labels, 'datasets' => [['data' => $status_data, 'backgroundColor' => $status_colors, 'project_titles' => $status_projects]]],
                'users' => ['labels' => $user_labels, 'datasets' => [['label' => __('Proyectos', 'projects'), 'data' => $user_data, 'backgroundColor' => '#0052CC']]]
            ],
            'projects_table' => $projects_table_html,
            'tasks_table' => $tasks_table_html
        ]);
    }

    /**
     * Renders the HTML for the projects table on the dashboard.
     */
    public function render_projects_table_html() {
        ?>
        <table class="projects-table"><thead><tr><th><?php _e('Proyecto','projects');?></th><th><?php _e('Prioridad','projects');?></th><th><?php _e('Estado','projects');?></th><th class="progress-column"><?php _e('Avance','projects');?></th><th><?php _e('Fecha Fin','projects');?></th><th></th></tr></thead><tbody>
        <?php 
        $current_user_id = get_current_user_id();
        $args = ['post_type' => 'project', 'posts_per_page' => -1, 'meta_query' => [['key' => '_project_responsable_id', 'value' => $current_user_id, 'compare' => '=']]];
        $projects_query = new WP_Query($args);
        $projects = $projects_query->posts;

        usort($projects, function($a, $b) {
            $priority_order = ['Alta' => 3, 'Media' => 2, 'Baja' => 1];
            $a_terms = get_the_terms($a->ID, 'project_priority');
            $b_terms = get_the_terms($b->ID, 'project_priority');
            $a_prio = !is_wp_error($a_terms) && !empty($a_terms) ? $a_terms[0]->name : 'Baja';
            $b_prio = !is_wp_error($b_terms) && !empty($b_terms) ? $b_terms[0]->name : 'Baja';
            return ($priority_order[$b_prio] ?? 0) <=> ($priority_order[$a_prio] ?? 0);
        });

        if (!empty($projects)) { foreach ($projects as $project_post) {
            $post_id = $project_post->ID;
            $all_statuses = get_terms(['taxonomy' => 'project_status', 'hide_empty' => false]);
            $priority_terms = get_the_terms($post_id, 'project_priority');
            $priority_name = !is_wp_error($priority_terms) && !empty($priority_terms) ? $priority_terms[0]->name : '—';
            $priority_slug = strtolower($priority_name);
            $status_terms = get_the_terms($post_id, 'project_status');
            $status_slug = !is_wp_error($status_terms) && !empty($status_terms) ? $status_terms[0]->slug : 'pending';
            $progress_map = ['pending' => 0, 'in-review' => 10, 'in-progress' => 35, 'qa-tests' => 65, 'completed' => 100];
            $progress = $progress_map[$status_slug] ?? 0;
            ?>
            <tr data-project-id="<?php echo $post_id; ?>">
                <td><a href="<?php echo get_permalink($post_id); ?>"><strong><?php echo get_the_title($post_id); ?></strong></a></td>
                <td><span class="priority-badge priority-<?php echo esc_attr($priority_slug); ?>"><?php echo esc_html($priority_name); ?></span></td>
                <td>
                    <select class="project-status-select">
                        <?php foreach($all_statuses as $status_term) {
                            echo '<option value="'.esc_attr($status_term->term_id).'" '.selected(has_term($status_term->term_id, 'project_status', $post_id), true, false).'>'.esc_html($status_term->name).'</option>';
                        } ?>
                    </select>
                </td>
                <td><div class="progress-bar-container"><div class="progress-bar" style="width: <?php echo $progress; ?>%;"></div><span><?php echo $progress; ?>%</span></div></td>
                <td><?php echo get_post_meta($post_id, '_project_end_date', true) ? esc_html(date_i18n(get_option('date_format'), strtotime(get_post_meta($post_id, '_project_end_date', true)))) : '—'; ?></td>
                <td class="action-cell"><button class="delete-project-btn">🗑️</button></td>
            </tr>
        <?php }} else { echo '<tr><td colspan="6">' . __('No tienes proyectos asignados.', 'projects') . '</td></tr>'; }
        wp_reset_postdata();
        ?>
        </tbody></table>
        <?php
    }

    /**
     * Renders the HTML for the pending tasks table on the dashboard.
     */
    public function render_dashboard_tasks_table_html() {
        $current_user_id = get_current_user_id();
        $in_progress_term = get_term_by('slug', 'in-progress', 'task_status');
        $todo_term = get_term_by('slug', 'to-do', 'task_status');
        
        $term_ids = [];
        if ($in_progress_term) $term_ids[] = $in_progress_term->term_id;
        if ($todo_term) $term_ids[] = $todo_term->term_id;

        $args = [
            'post_type' => 'task',
            'posts_per_page' => -1,
            'author' => $current_user_id,
            'tax_query' => [
                ['taxonomy' => 'task_status', 'field' => 'term_id', 'terms' => $term_ids]
            ]
        ];
        $tasks_query = new WP_Query($args);
        $tasks = $tasks_query->posts;

        usort($tasks, function($a, $b) {
            $status_order = ['in-progress' => 2, 'to-do' => 1];
            $a_terms = get_the_terms($a->ID, 'task_status');
            $b_terms = get_the_terms($b->ID, 'task_status');
            $a_status = !is_wp_error($a_terms) && !empty($a_terms) ? $a_terms[0]->slug : 'to-do';
            $b_status = !is_wp_error($b_terms) && !empty($b_terms) ? $b_terms[0]->slug : 'to-do';
            return ($status_order[$b_status] ?? 0) <=> ($status_order[$a_status] ?? 0);
        });
        ?>
        <table class="tasks-table">
            <thead><tr><th><?php _e('Tarea', 'projects'); ?></th><th><?php _e('Proyecto', 'projects'); ?></th><th><?php _e('Estado', 'projects'); ?></th><th><?php _e('Fecha Fin', 'projects'); ?></th></tr></thead>
            <tbody>
                <?php if (!empty($tasks)) : foreach ($tasks as $task_post) : 
                    $task_id = $task_post->ID;
                    $project_id = $task_post->post_parent;
                    $project_title = get_the_title($project_id);
                    $project_link = get_permalink($project_id);
                    $status_terms = get_the_terms($task_id, 'task_status');
                    $status_name = !is_wp_error($status_terms) && !empty($status_terms) ? $status_terms[0]->name : '—';
                    $end_date = get_post_meta($task_id, '_task_end_date', true);
                ?>
                <tr data-task-id="<?php echo $task_id; ?>">
                    <td><a href="<?php echo esc_url($project_link); ?>"><strong><?php echo get_the_title($task_id); ?></strong></a></td>
                    <td><a href="<?php echo esc_url($project_link); ?>"><?php echo esc_html($project_title); ?></a></td>
                    <td><?php echo esc_html($status_name); ?></td>
                    <td><?php echo $end_date ? esc_html(date_i18n(get_option('date_format'), strtotime($end_date))) : '—'; ?></td>
                </tr>
                <?php endforeach; else : ?>
                    <tr><td colspan="4"><?php _e('No tienes tareas pendientes.', 'projects'); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php
    }

    public function ajax_get_project_tasks() {
        check_ajax_referer('projects-frontend-nonce', 'nonce');
        if ( !isset($_POST['project_id']) ) wp_send_json_error('Project ID is missing.');
        
        ob_start();
        $this->render_tasks_table_html( intval($_POST['project_id']), isset($_POST['status_filter']) ? sanitize_text_field($_POST['status_filter']) : 'active' );
        $table_html = ob_get_clean();
        wp_send_json_success(['table_html' => $table_html]);
    }

    public function render_tasks_table_html( $project_id, $status_filter = 'active' ) {
        $done_term = get_term_by('slug', 'done', 'task_status');
        $tax_query = [];
        if ($done_term) {
            if ($status_filter === 'completed') {
                $tax_query[] = ['taxonomy' => 'task_status', 'field' => 'term_id', 'terms' => $done_term->term_id];
            } else {
                $tax_query[] = ['taxonomy' => 'task_status', 'field' => 'term_id', 'terms' => $done_term->term_id, 'operator' => 'NOT IN'];
            }
        }
        
        $args = [ 'post_type' => 'task', 'posts_per_page' => -1, 'post_parent' => $project_id, 'tax_query' => $tax_query ];
        $tasks_query = new WP_Query($args);
        ?>
        <table class="tasks-table">
            <thead><tr><th><?php _e('Tarea', 'projects'); ?></th><th><?php _e('Prioridad', 'projects'); ?></th><th><?php _e('Estado', 'projects'); ?></th><th><?php _e('Responsable', 'projects'); ?></th><th><?php _e('Fecha Fin', 'projects'); ?></th><th></th></tr></thead>
            <tbody>
                <?php if ( $tasks_query->have_posts() ) : while ( $tasks_query->have_posts() ) : $tasks_query->the_post(); 
                        $task_id = get_the_ID();
                        $all_task_statuses = get_terms(['taxonomy' => 'task_status', 'hide_empty' => false]);
                        $priority_terms = get_the_terms($task_id, 'project_priority');
                        $priority_name = !is_wp_error($priority_terms) && !empty($priority_terms) ? $priority_terms[0]->name : '—';
                        $priority_slug = strtolower($priority_name);
                        $end_date = get_post_meta($task_id, '_task_end_date', true);
                    ?>
                        <tr data-task-id="<?php echo $task_id; ?>">
                            <td><strong><?php the_title(); ?></strong></td>
                            <td><span class="priority-badge priority-<?php echo esc_attr($priority_slug); ?>"><?php echo esc_html($priority_name); ?></span></td>
                            <td>
                                <select class="task-status-select">
                                    <?php foreach($all_task_statuses as $status_term) {
                                        echo '<option value="'.esc_attr($status_term->term_id).'" '.selected(has_term($status_term->term_id, 'task_status', $task_id), true, false).'>'.esc_html($status_term->name).'</option>';
                                    } ?>
                                </select>
                            </td>
                            <td><?php echo get_the_author(); ?></td>
                            <td><?php echo $end_date ? esc_html(date_i18n(get_option('date_format'), strtotime($end_date))) : '—'; ?></td>
                            <td class="action-cell"><button class="delete-task-btn">🗑️</button></td>
                        </tr>
                    <?php endwhile; wp_reset_postdata(); else : ?>
                    <tr><td colspan="6"><?php _e('No hay tareas en esta vista.', 'projects'); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php
    }
    
    public function ajax_create_new_project() {
        check_ajax_referer('projects-frontend-nonce', 'nonce');
        if (!isset($_POST['title']) || empty($_POST['title'])) wp_send_json_error(['message' => 'El título es obligatorio.']);
        if (!current_user_can('publish_posts')) wp_send_json_error(['message' => 'Permiso denegado.']);

        $post_id = wp_insert_post(['post_title' => sanitize_text_field($_POST['title']),'post_content' => sanitize_textarea_field($_POST['content']),'post_status'  => 'publish','post_type'    => 'project','post_author'  => get_current_user_id()]);
        if (is_wp_error($post_id)) { wp_send_json_error(['message' => $post_id->get_error_message()]); } 
        else {
            update_post_meta($post_id, '_project_responsable_id', get_current_user_id());
            if (!empty($_POST['start_date'])) update_post_meta($post_id, '_project_start_date', sanitize_text_field($_POST['start_date']));
            if (!empty($_POST['end_date'])) update_post_meta($post_id, '_project_end_date', sanitize_text_field($_POST['end_date']));
            if (!empty($_POST['priority'])) wp_set_post_terms($post_id, [intval($_POST['priority'])], 'project_priority');
            if (!empty($_POST['tags'])) wp_set_post_terms($post_id, sanitize_text_field($_POST['tags']), 'project_tag');
            $pending_status = get_term_by('slug', 'pending', 'project_status');
            if ($pending_status) wp_set_post_terms($post_id, [$pending_status->term_id], 'project_status');
            wp_send_json_success(['message' => 'Proyecto creado con éxito.']);
        }
    }

    public function ajax_create_new_task() {
        check_ajax_referer('projects-frontend-nonce', 'nonce');
        if (!isset($_POST['title']) || empty($_POST['title'])) wp_send_json_error(['message' => 'El título de la tarea es obligatorio.']);
        if (!isset($_POST['project_id']) || empty($_POST['project_id'])) wp_send_json_error(['message' => 'ID de proyecto no encontrado.']);

        $task_id = wp_insert_post(['post_title' => sanitize_text_field($_POST['title']),'post_content' => sanitize_textarea_field($_POST['description']),'post_status'   => 'publish','post_type'     => 'task','post_parent'   => intval($_POST['project_id']),'post_author'   => get_current_user_id()]);
        if (is_wp_error($task_id)) { wp_send_json_error(['message' => $task_id->get_error_message()]); } 
        else {
            if (!empty($_POST['start_date'])) update_post_meta($task_id, '_task_start_date', sanitize_text_field($_POST['start_date']));
            if (!empty($_POST['end_date'])) update_post_meta($task_id, '_task_end_date', sanitize_text_field($_POST['end_date']));
            if (!empty($_POST['estimated_time'])) update_post_meta($task_id, '_task_estimated_time', sanitize_text_field($_POST['estimated_time']));
            if (!empty($_POST['priority'])) wp_set_post_terms($task_id, [intval($_POST['priority'])], 'project_priority');
            if (!empty($_POST['tags'])) wp_set_post_terms($task_id, sanitize_text_field($_POST['tags']), 'project_tag');
            if (!empty($_POST['status'])) wp_set_post_terms($task_id, [intval($_POST['status'])], 'task_status');
            wp_send_json_success(['message' => 'Tarea creada con éxito.']);
        }
    }

    public function ajax_update_project_status() {
        check_ajax_referer('projects-frontend-nonce', 'nonce');
        if(!isset($_POST['project_id']) || !isset($_POST['status_id'])) wp_send_json_error('Datos incompletos.');
        $project_id = intval($_POST['project_id']);
        $status_id = intval($_POST['status_id']);
        if(!current_user_can('edit_post', $project_id)) wp_send_json_error('Permiso denegado.');
        
        $result = wp_set_post_terms($project_id, [$status_id], 'project_status');
        if (is_wp_error($result)) { wp_send_json_error($result->get_error_message()); } 
        else { wp_send_json_success('Estado actualizado.'); }
    }
    
    public function ajax_update_task_status() {
        check_ajax_referer('projects-frontend-nonce', 'nonce');
        if(!isset($_POST['task_id']) || !isset($_POST['status_id'])) wp_send_json_error('Datos incompletos.');
        $task_id = intval($_POST['task_id']);
        $status_id = intval($_POST['status_id']);
        if(!current_user_can('edit_post', $task_id)) wp_send_json_error('Permiso denegado.');
        
        $result = wp_set_post_terms($task_id, [$status_id], 'task_status');
        if (is_wp_error($result)) { wp_send_json_error($result->get_error_message()); } 
        else { wp_send_json_success('Estado de tarea actualizado.'); }
    }

    public function ajax_delete_project() {
        check_ajax_referer('projects-frontend-nonce', 'nonce');
        if (!isset($_POST['project_id'])) wp_send_json_error('ID de proyecto no proporcionado.');
        $project_id = intval($_POST['project_id']);
        if (!current_user_can('delete_post', $project_id)) wp_send_json_error('No tienes permiso para eliminar este proyecto.');
        $result = wp_delete_post($project_id, true);
        if ($result === false) { wp_send_json_error('Error al eliminar el proyecto.'); } 
        else { wp_send_json_success('Proyecto eliminado con éxito.'); }
    }

    public function ajax_delete_task() {
        check_ajax_referer('projects-frontend-nonce', 'nonce');
        if (!isset($_POST['task_id'])) wp_send_json_error('ID de tarea no proporcionado.');
        $task_id = intval($_POST['task_id']);
        if (!current_user_can('delete_post', $task_id)) wp_send_json_error('No tienes permiso para eliminar esta tarea.');
        $result = wp_delete_post($task_id, true);
        if ($result === false) { wp_send_json_error('Error al eliminar la tarea.'); } 
        else { wp_send_json_success('Tarea eliminada con éxito.'); }
    }
}
