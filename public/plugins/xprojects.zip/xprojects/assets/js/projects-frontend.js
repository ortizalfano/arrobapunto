jQuery(document).ready(function($) {

    // --- LÓGICA GENERAL DE MODALES ---
    // Cierra cualquier modal al hacer clic en el botón de cancelar o en el fondo
    $(document).on('click', '.cancel-modal-btn', function() {
        $(this).closest('.project-modal-overlay').hide();
    });
    $(document).on('click', '.project-modal-overlay', function(e) {
        if (e.target === this) {
            $(this).hide();
        }
    });

    // --- LÓGICA DEL DASHBOARD DE PROYECTOS ---
    const dashboard = $('.projects-jira-dashboard');
    if (dashboard.length) {
        let statusChart, userChart;
        let itemToDelete = { id: null, type: null };

        function loadDashboardData() {
            $('#projects-table-container').html('<div class="spinner-container"><span class="spinner is-active"></span></div>');
            $('#dashboard-tasks-container').html('<div class="spinner-container"><span class="spinner is-active"></span></div>');

            $.ajax({
                url: projects_ajax_obj.ajax_url,
                type: 'POST',
                data: { action: 'get_project_dashboard_data', nonce: projects_ajax_obj.nonce },
                success: function(response) {
                    if (response.success) {
                        $('#projects-table-container').html(response.data.projects_table);
                        $('#dashboard-tasks-container').html(response.data.tasks_table);
                        renderStatusChart(response.data.charts.status);
                        renderUserChart(response.data.charts.users);
                    } else {
                        $('#projects-table-container').html('<p>Error: No se pudieron cargar los datos.</p>');
                        $('#dashboard-tasks-container').html('');
                    }
                },
                error: function() { 
                    $('#projects-table-container').html('<p>Error de red.</p>');
                    $('#dashboard-tasks-container').html('');
                }
            });
        }

        function renderStatusChart(data) {
            const ctx = document.getElementById('projectStatusChart')?.getContext('2d');
            if (!ctx) return;
            if (statusChart) statusChart.destroy();
            statusChart = new Chart(ctx, { type: 'doughnut', data: data, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: true, position: 'right' }, tooltip: { callbacks: { footer: function(tooltipItems) { let projectTitles = tooltipItems[0].dataset.project_titles[tooltipItems[0].dataIndex] || []; let displayTitles = projectTitles.slice(0, 5); let footer = displayTitles.join('\n'); if (projectTitles.length > 5) { footer += '\n...'; } return footer; } } } } }, });
        }

        function renderUserChart(data) {
            const ctx = document.getElementById('projectUserChart')?.getContext('2d');
            if (!ctx) return;
            if (userChart) userChart.destroy();
            userChart = new Chart(ctx, { type: 'bar', data: data, options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }, });
        }
        
        loadDashboardData();

        $(document).on('change', '.projects-table .project-status-select', function() {
            const select = $(this);
            const row = select.closest('tr');
            const spinner = row.find('.spinner');
            const saveStatus = row.find('.save-status');
            spinner.addClass('is-active');
            saveStatus.empty();

            $.ajax({
                url: projects_ajax_obj.ajax_url,
                type: 'POST',
                data: { action: 'update_project_status', nonce: projects_ajax_obj.nonce, project_id: row.data('project-id'), status_id: select.val() },
                success: function(response) {
                    if (response.success) {
                        saveStatus.text('✔️').css('color', 'green');
                        loadDashboardData(); // Recargar para actualizar la barra de progreso
                    } else {
                        saveStatus.text('❌').css('color', 'red');
                    }
                },
                error: function() { saveStatus.text('❌').css('color', 'red'); },
                complete: function() { spinner.removeClass('is-active'); setTimeout(() => saveStatus.empty(), 2000); }
            });
        });

        const deleteModal = $('#delete-confirm-modal');
        $(document).on('click', '.delete-project-btn', function() {
            itemToDelete = { id: $(this).closest('tr').data('project-id'), type: 'project' };
            deleteModal.find('.modal-context-item').text('proyecto');
            deleteModal.css('display', 'flex');
        });

        $('#confirm-delete-btn').on('click', function() {
            if (!itemToDelete || !itemToDelete.id) return;
            const action = 'delete_' + itemToDelete.type;
            const idKey = itemToDelete.type + '_id';

            $(this).text('Eliminando...');
            $.ajax({
                url: projects_ajax_obj.ajax_url, type: 'POST',
                data: { action: action, nonce: projects_ajax_obj.nonce, [idKey]: itemToDelete.id },
                success: function(response) {
                    if(response.success) {
                        deleteModal.hide();
                        if (itemToDelete.type === 'project') {
                           loadDashboardData();
                        }
                    } else {
                        alert('Error: ' + response.data.message);
                    }
                },
                complete: function() {
                    $('#confirm-delete-btn').text('Sí, eliminar');
                }
            });
        });

        const addProjectModal = $('#add-project-modal');
        $(document).on('click', '#add-project-btn', function() {
            const defaultPriority = addProjectModal.find('.priority-option.active');
            addProjectModal.find('#new_project_priority').val(defaultPriority.data('value'));
            addProjectModal.css('display', 'flex');
        });
        
        addProjectModal.on('click', '.priority-option', function() {
            $(this).siblings().removeClass('active');
            $(this).addClass('active');
            addProjectModal.find('#new_project_priority').val($(this).data('value'));
        });

        addProjectModal.on('submit', '#add-project-form', function(e) {
            e.preventDefault();
            const form = $(this);
            const spinner = form.find('.spinner');
            const statusDiv = form.find('.modal-status');
            spinner.addClass('is-active');
            statusDiv.empty();
            $.ajax({
                url: projects_ajax_obj.ajax_url,
                type: 'POST',
                data: {
                    action: 'create_new_project',
                    nonce: projects_ajax_obj.nonce,
                    title: $('#new_project_title').val(),
                    content: $('#new_project_content').val(),
                    start_date: $('#new_project_start_date').val(),
                    end_date: $('#new_project_end_date').val(),
                    priority: $('#new_project_priority').val(),
                    tags: $('#new_project_tags').val()
                },
                success: function(response) {
                    if (response.success) {
                        statusDiv.text(response.data.message).css('color', 'green');
                        setTimeout(() => { addProjectModal.hide(); form[0].reset(); loadDashboardData(); }, 1500);
                    } else {
                        statusDiv.text(response.data.message || 'Error desconocido.').css('color', 'red');
                    }
                },
                error: function() { statusDiv.text('Ocurrió un error de red.').css('color', 'red'); },
                complete: function() { spinner.removeClass('is-active'); }
            });
        });
    }


    // --- LÓGICA DE LA PÁGINA DE PROYECTO INDIVIDUAL ---
    const singleProjectContainer = $('.single-project-container');
    if (singleProjectContainer.length) {
        const projectId = singleProjectContainer.data('project-id');
        let itemToDelete = { id: null, type: null };
        
        $('#back-to-dashboard-btn').attr('href', projects_ajax_obj.dashboard_url);

        function loadTasksForProject(projectId, statusFilter = 'active') {
            const container = $('#tasks-table-container');
            container.html('<div class="spinner-container"><span class="spinner is-active"></span></div>');
            $.ajax({
                url: projects_ajax_obj.ajax_url, type: 'POST',
                data: { action: 'get_project_tasks', nonce: projects_ajax_obj.nonce, project_id: projectId, status_filter: statusFilter },
                success: function(response) {
                    if (response.success) { container.html(response.data.table_html); } 
                    else { container.html('<p>Error al cargar las tareas.</p>'); }
                }
            });
        }
        
        loadTasksForProject(projectId, 'active');

        $('.tasks-tabs').on('click', '.tab-item', function() {
            const tab = $(this);
            if (tab.hasClass('active')) return;
            tab.siblings().removeClass('active');
            tab.addClass('active');
            loadTasksForProject(projectId, tab.data('filter'));
        });

        $(document).on('change', '.tasks-table .task-status-select', function() {
            const select = $(this);
            const row = select.closest('tr');
            $.ajax({
                url: projects_ajax_obj.ajax_url, type: 'POST',
                data: { action: 'update_task_status', nonce: projects_ajax_obj.nonce, task_id: row.data('task-id'), status_id: select.val() },
                success: function(response) {
                    if (response.success) {
                        const currentFilter = $('.tasks-tabs .tab-item.active').data('filter');
                        loadTasksForProject(projectId, currentFilter);
                    }
                }
            });
        });

        const deleteModal = $('#delete-confirm-modal');
        $(document).on('click', '.delete-task-btn', function() {
            itemToDelete = { id: $(this).closest('tr').data('task-id'), type: 'task' };
            deleteModal.find('.modal-context-item').text('la tarea');
            deleteModal.css('display', 'flex');
        });

        $('#confirm-delete-btn').on('click', function() {
            if (!itemToDelete || !itemToDelete.id) return;
            const action = 'delete_' + itemToDelete.type;
            const idKey = itemToDelete.type + '_id';
            
            $.ajax({
                url: projects_ajax_obj.ajax_url, type: 'POST',
                data: { action: action, nonce: projects_ajax_obj.nonce, [idKey]: itemToDelete.id },
                success: function(response) {
                    if(response.success) {
                        deleteModal.hide();
                        const currentFilter = $('.tasks-tabs .tab-item.active').data('filter');
                        loadTasksForProject(projectId, currentFilter);
                    }
                }
            });
        });
        
        const addTaskModal = $('#add-task-modal');
        $(document).on('click', '#add-task-btn', function() {
            $('#parent_project_id').val(projectId);
            const defaultPriority = addTaskModal.find('.priority-option.active');
            $('#new_task_priority').val(defaultPriority.data('value'));
            addTaskModal.css('display', 'flex');
        });
        
        addTaskModal.on('click', '.priority-option', function() {
            $(this).siblings().removeClass('active').end().addClass('active');
            $('#new_task_priority').val($(this).data('value'));
        });

        addTaskModal.on('submit', '#add-task-form', function(e) {
            e.preventDefault();
            const form = $(this);
            const spinner = form.find('.spinner');
            const statusDiv = form.find('.modal-status');
            spinner.addClass('is-active');
            statusDiv.empty();

            $.ajax({
                url: projects_ajax_obj.ajax_url,
                type: 'POST',
                data: {
                    action: 'create_new_task',
                    nonce: projects_ajax_obj.nonce,
                    project_id: $('#parent_project_id').val(),
                    title: $('#new_task_title').val(),
                    description: $('#new_task_description').val(),
                    start_date: $('#new_task_start_date').val(),
                    end_date: $('#new_task_end_date').val(),
                    priority: $('#new_task_priority').val(),
                    status: $('#new_task_status').val(),
                    tags: $('#new_task_tags').val(),
                    estimated_time: $('#new_task_estimated_time').val()
                },
                success: function(response) {
                    if (response.success) {
                        statusDiv.text(response.data.message).css('color', 'green');
                        setTimeout(() => { addTaskModal.hide(); form[0].reset(); loadTasksForProject(projectId); }, 1500);
                    } else {
                        statusDiv.text(response.data.message || 'Error.').css('color', 'red');
                    }
                },
                error: function() { statusDiv.text('Error de red.').css('color', 'red'); },
                complete: function() { spinner.removeClass('is-active'); }
            });
        });
    }
});
