<?php
/**
 * Plugin Name:       xProjects
 * Plugin URI:        https://arrobapunto.com/plugins/
 * Description:       Añade un sistema de seguimiento de proyectos con un portal frontend profesional interactivo.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Omar Ortiz Alfano
 * Author URI:        https://arrobapunto.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       xprojects
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// 1. Definir constantes del plugin
define( 'PROJECTS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'PROJECTS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PROJECTS_PLUGIN_VERSION', '5.5.0' );

// 2. Cargar los archivos principales del plugin
require_once PROJECTS_PLUGIN_PATH . 'includes/cpt.php';
require_once PROJECTS_PLUGIN_PATH . 'includes/template-loader.php';
require_once PROJECTS_PLUGIN_PATH . 'includes/ajax-handlers.php';

// 3. Clase principal del Plugin
class Projects_Tracker {
    public function __construct() {
        register_activation_hook(__FILE__, [ $this, 'activate_plugin' ]);
        
        new Projects_CPT();
        new Projects_Template_Loader();
        new Projects_Ajax_Handlers();

        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        add_shortcode('projects_dashboard', [$this, 'render_projects_dashboard_shortcode']);
        add_action('wp_footer', [$this, 'add_modals_to_footer']);
    }

    public function activate_plugin() {
        $cpt_manager = new Projects_CPT();
        $cpt_manager->register_post_types_and_taxonomies();
        $cpt_manager->register_default_terms();
        flush_rewrite_rules();

        $option_key = 'projects_portal_page_id';
        if ( ! get_option($option_key) || ! get_post(get_option($option_key)) ) {
            $page_id = wp_insert_post([
                'post_title'    => __( 'Portal de Proyectos', 'projects' ),
                'post_content'  => '[projects_dashboard]',
                'post_status'   => 'publish',
                'post_type'     => 'page',
            ]);
            if ( $page_id ) {
                update_option( $option_key, $page_id );
            }
        }
    }

    public function enqueue_frontend_assets() {
        global $post;
        if ( (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'projects_dashboard')) || is_singular('project') ) {
            wp_enqueue_style( 'projects-frontend-style', PROJECTS_PLUGIN_URL . 'assets/css/projects-frontend.css', [], PROJECTS_PLUGIN_VERSION );
            wp_enqueue_script( 'chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '3.7.0', true );
            wp_enqueue_script( 'projects-frontend-js', PROJECTS_PLUGIN_URL . 'assets/js/projects-frontend.js', [ 'jquery', 'chart-js' ], PROJECTS_PLUGIN_VERSION, true );
            
            $dashboard_page_url = get_option('projects_portal_page_id') ? get_permalink(get_option('projects_portal_page_id')) : home_url();

            wp_localize_script( 'projects-frontend-js', 'projects_ajax_obj', [ 
                'ajax_url' => admin_url( 'admin-ajax.php' ), 
                'nonce' => wp_create_nonce( 'projects-frontend-nonce' ),
                'dashboard_url' => $dashboard_page_url
            ]);
        }
    }

    public function render_projects_dashboard_shortcode() {
        if ( ! is_user_logged_in() ) { return '<div class="projects-login-prompt">' . __( 'Por favor, inicia sesión para ver tus proyectos.', 'projects' ) . ' <a href="' . wp_login_url( get_permalink() ) . '">' . __( 'Iniciar Sesión', 'projects' ) . '</a></div>'; }
        
        return '<div class="projects-jira-dashboard" data-context="dashboard">
                    <div class="dashboard-main-column">
                        <div class="widget-box">
                            <div class="widget-box-header"><h3>' . __('Mis Proyectos Asignados', 'projects') . '</h3><button id="add-project-btn" class="button button-primary">' . __('Añadir Proyecto', 'projects') . '</button></div>
                            <div class="widget-box-content"><div id="projects-table-container"><div class="spinner-container"><span class="spinner is-active"></span></div></div></div>
                        </div>
                        <div class="widget-box">
                            <div class="widget-box-header"><h3>' . __('Mis Tareas Pendientes', 'projects') . '</h3></div>
                            <div class="widget-box-content"><div id="dashboard-tasks-container"><div class="spinner-container"><span class="spinner is-active"></span></div></div></div>
                        </div>
                    </div>
                    <div class="dashboard-side-column">
                        <div class="widget-box"><div class="widget-box-header"><h3>' . __('Proyectos por Estado', 'projects') . '</h3></div><div class="widget-box-content"><div class="chart-wrapper"><canvas id="projectStatusChart"></canvas></div></div></div>
                        <div class="widget-box"><div class="widget-box-header"><h3>' . __('Proyectos por Usuario', 'projects') . '</h3></div><div class="widget-box-content"><div class="chart-wrapper"><canvas id="projectUserChart"></canvas></div></div></div>
                    </div>
                </div>';
    }

    public function add_modals_to_footer() {
        if ( !is_user_logged_in() || !((is_a($GLOBALS['post'], 'WP_Post') && has_shortcode($GLOBALS['post']->post_content, 'projects_dashboard')) || is_singular('project')) ) { return; }
        include_once PROJECTS_PLUGIN_PATH . 'templates/modals.php';
    }
}
new Projects_Tracker();
