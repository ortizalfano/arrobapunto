jQuery(document).ready(function($) {
    let file_frame;

    $('#upload_logo_button').on('click', function(event) {
        event.preventDefault();

        // Si el marco ya existe, simplemente ábrelo.
        if (file_frame) {
            file_frame.open();
            return;
        }

        // Crea un nuevo marco de medios.
        file_frame = wp.media({
            title: 'Selecciona o sube un logo',
            button: {
                text: 'Usar este logo'
            },
            multiple: false // Solo permitir seleccionar una imagen.
        });

        // Cuando se selecciona una imagen, ejecuta este código.
        file_frame.on('select', function() {
            // Obtiene los datos adjuntos de la imagen seleccionada.
            const attachment = file_frame.state().get('selection').first().toJSON();

            // Actualiza el campo oculto con la URL de la imagen.
            $('#xinvoice_logo_url').val(attachment.url);

            // Muestra la vista previa de la imagen.
            $('.logo-preview').html('<img src="' + attachment.url + '" style="max-width: 200px; height: auto;">');

            // Muestra el botón de "Quitar Logo".
            $('#remove_logo_button').show();
        });

        // Abre el marco de medios.
        file_frame.open();
    });

    $('#remove_logo_button').on('click', function(event) {
        event.preventDefault();

        // Vacía el campo oculto.
        $('#xinvoice_logo_url').val('');

        // Elimina la vista previa.
        $('.logo-preview').html('');

        // Oculta el botón de "Quitar Logo".
        $(this).hide();
    });
});