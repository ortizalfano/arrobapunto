jQuery(document).ready(function($) {
    
    // --- GESTIÓN DE LA VISIBILIDAD DE IMPUESTOS (VERSIÓN SEGURA) ---
    if (typeof xinvoice_data !== 'undefined' && xinvoice_data.enable_tax !== 'on') {
        $('.xinvoice-tax-row').hide();
        $('#invoice-tax-rate').val(0);
    }

    // --- FUNCIONES DE CÁLCULO Y MANEJO DE FILAS ---
    
    function updateGrandTotals() {
        let subtotal = 0;
        $('.invoice-item-row').each(function() {
            const quantity = parseFloat($(this).find('.item-quantity').val()) || 0;
            const price = parseFloat($(this).find('.item-price').val()) || 0;
            subtotal += quantity * price;
        });
        const taxRate = parseFloat($('#invoice-tax-rate').val()) || 0;
        const taxAmount = subtotal * (taxRate / 100);
        const grandTotal = subtotal + taxAmount;
        $('#invoice-subtotal').text(subtotal.toFixed(2));
        $('#invoice-grand-total').text(grandTotal.toFixed(2));
    }

    function calculateRowTotal(row) {
        const quantity = parseFloat(row.find('.item-quantity').val()) || 0;
        const price = parseFloat(row.find('.item-price').val()) || 0;
        const total = quantity * price;
        row.find('.item-total-display strong').text(total.toFixed(2));
    }

    let itemIndex = 0;
    function addNewItemRow(item = {}) {
        itemIndex++;
        const description = item.description || '';
        const quantity = item.quantity || 1;
        const price = item.price || '';
        
        const rowHTML = `
            <tr class="invoice-item-row">
                <td><input type="text" name="invoice_items[${itemIndex}][description]" class="large-text" placeholder="Descripción" value="${description}"></td>
                <td><input type="number" name="invoice_items[${itemIndex}][quantity]" class="item-quantity" placeholder="1" min="0" value="${quantity}"></td>
                <td><input type="number" name="invoice_items[${itemIndex}][price]" class="item-price" placeholder="0.00" min="0" step="any" value="${price}"></td>
                <td class="item-total-display"><strong>0.00</strong></td>
                <td><a href="#" class="remove-item-row button icon"><span class="dashicons dashicons-trash"></span></a></td>
            </tr>`;
        $('#invoice-item-rows').append(rowHTML);
        calculateRowTotal($('#invoice-item-rows').find('tr').last());
    }

    // --- EVENTOS DEL FORMULARIO ---

    $('#add-invoice-item').on('click', function(e) { e.preventDefault(); addNewItemRow(); updateGrandTotals(); });
    $('#xinvoice_details_meta_box').on('click', '.remove-item-row', function(e) { e.preventDefault(); $(this).closest('tr').remove(); updateGrandTotals(); });
    $('#xinvoice_details_meta_box').on('input', '.item-quantity, .item-price, #invoice-tax-rate', function() { if ($(this).is('.item-quantity, .item-price')) { const row = $(this).closest('tr'); calculateRowTotal(row); } updateGrandTotals(); });

    // --- CARGA INICIAL DE DATOS ---

    if (typeof xinvoice_data !== 'undefined' && Array.isArray(xinvoice_data.items) && xinvoice_data.items.length > 0) {
        xinvoice_data.items.forEach(item => { if (item) { addNewItemRow(item); } });
    } else {
        addNewItemRow();
    }
    updateGrandTotals();

    // --- LÓGICA PARA GENERAR PDF ---
    
    $('#xinvoice-download-pdf').on('click', function() {
        const { jsPDF } = window.jspdf;
        const invoiceTitle = $('#title').val() || $('input[name="post_title"]').val() || 'Factura';

        // --- 1. Construir el HTML de la plantilla ---
        let itemsHTML = '';
        $('.invoice-item-row').each(function() {
            const description = $(this).find('input[name*="[description]"]').val();
            const quantity = $(this).find('.item-quantity').val();
            const price = parseFloat($(this).find('.item-price').val() || 0).toFixed(2);
            const total = (quantity * price).toFixed(2);
            itemsHTML += `<tr><td>${description}</td><td>${quantity}</td><td>${price} €</td><td>${total} €</td></tr>`;
        });
        
        const taxAmount = (parseFloat($('#invoice-subtotal').text()) * parseFloat($('#invoice-tax-rate').val()) / 100).toFixed(2);

        const templateHTML = `
            <div class="invoice-pdf-template">
                <div class="pdf-header">
                    <div class="col-left">
                        <img src="${xinvoice_data.logo_url}" class="logo">
                    </div>
                    <div class="invoice-title">
                        <h1>FACTURA</h1>
                        <p><strong>Factura #:</strong> ${invoiceTitle}</p>
                        <p><strong>Fecha:</strong> ${$('#invoice_date').val()}</p>
                    </div>
                </div>
                <div class="addresses">
                    <div class="col-left">
                        <strong>De:</strong><br>
                        <strong>${xinvoice_data.company_name}</strong><br>
                        ${xinvoice_data.company_details.replace(/\n/g, '<br>')}
                    </div>
                    <div class="col-right">
                        <strong>Cobrar a:</strong><br>
                        <strong>${$('#client_name').val()}</strong><br>
                        ${$('#client_email').val()}
                    </div>
                </div>
                <table class="line-items-table">
                    <thead><tr><th>Descripción</th><th>Cantidad</th><th>Precio Unitario</th><th>Total</th></tr></thead>
                    <tbody>${itemsHTML}</tbody>
                </table>
                <div class="totals">
                    <p><strong>Subtotal:</strong> ${$('#invoice-subtotal').text()} €</p>
                    <p><strong>Impuestos (${$('#invoice-tax-rate').val()}%):</strong> ${taxAmount} €</p>
                    <h3>Total: ${$('#invoice-grand-total').text()} €</h3>
                </div>
            </div>
        `;

        $('#xinvoice-pdf-render-wrapper').html(templateHTML);

        // --- 2. Usar html2canvas y jsPDF para crear el PDF ---
        const invoiceElement = document.getElementById('xinvoice-pdf-render-wrapper');
        
        html2canvas(invoiceElement, { scale: 2 }).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
            
            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            pdf.save(`${invoiceTitle}.pdf`);
        });
    });
});