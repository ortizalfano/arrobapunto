=== xInvoice ===
Contributors: (ortizalfano)
Donate link: https://arrobapunto.com
Tags: invoice, invoices, pdf invoice, billing, freelance
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Un generador de facturas elegante y fácil de usar, diseñado para freelancers y creativos dentro de WordPress.

== Description ==

xInvoice es la forma más sencilla y elegante de gestionar tus facturas sin salir de WordPress. Creado con una filosofía "plug and play", te permite crear, gestionar y descargar facturas en PDF con una interfaz limpia e intuitiva.

= Funcionalidades Principales =

* **Creación Rápida de Facturas:** Un formulario claro y sencillo para añadir clientes y conceptos.
* **Cálculos Automáticos:** El plugin calcula subtotales, impuestos y totales en tiempo real.
* **Descarga en PDF:** Genera un PDF profesional de tu factura con un solo clic.
* **Gestión de Estados:** Marca tus facturas como Borrador, Enviada, Pagada o Vencida para un seguimiento visual.
* **Numeración Automática:** Las facturas se numeran secuencialmente (FAC0001, FAC0002...).
* **Ajustes Personalizables:** Sube tu propio logo y añade los datos de tu empresa para personalizar tus facturas.

== Installation ==

1.  Sube la carpeta `xinvoice` al directorio `/wp-content/plugins/`.
2.  Activa el plugin a través del menú 'Plugins' en WordPress.
3.  Ve a "Facturas > Ajustes" para configurar los datos de tu empresa y subir tu logo.
4.  ¡Empieza a crear facturas desde el menú "Facturas > Crear Factura"!

== Frequently Asked Questions ==

= ¿Este plugin es realmente gratuito? =

Sí, todas las funcionalidades descritas son 100% gratuitas. En el futuro planeamos lanzar una versión Premium con funcionalidades avanzadas.

= ¿Puedo personalizar el diseño de la factura? =

La versión actual utiliza una plantilla de PDF limpia y profesional. La personalización avanzada de plantillas será una característica de la versión Premium.

== Screenshots ==

1.  La lista principal de facturas con los estados de colores.
2.  La página de creación de una factura.
3.  La página de ajustes del plugin.
4.  Ejemplo de un PDF generado.

== Changelog ==

= 1.0.0 =
* Lanzamiento inicial del plugin.

== Upgrade Notice ==

= 1.0.0 =
* ¡La primera versión de xInvoice está aquí! Disfruta de una gestión de facturas sencilla y elegante.