<?php
/**
 * Plugin Name:       xInvoice
 * Plugin URI:        https://arrobapunto.com/plugins/
 * Description:       Un generador de facturas elegante y fácil de usar, diseñado para freelancers y creativos dentro de WordPress.
 * Version:           1.0.0
 * Author:            Omar Ortiz Alfano
 * Author URI:        https://arrobapunto.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       xinvoice
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) die;

// =============================================================================
// 1. REGISTRO DEL CUSTOM POST TYPE 'INVOICE'
// =============================================================================
function xinvoice_register_invoice_cpt() {
    $labels = [
        'name'          => __( 'Facturas', 'xinvoice' ),
        'singular_name' => __( 'Factura', 'xinvoice' ),
        'add_new'       => __( 'Crear Factura', 'xinvoice' ),
        'add_new_item'  => __( 'Crear Nueva Factura', 'xinvoice' ),
        'edit_item'     => __( 'Editar Factura', 'xinvoice' ),
        'all_items'     => __( 'Todas las Facturas', 'xinvoice' ),
    ];
    $args = [
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-media-text',
        'capability_type'    => 'post',
        'map_meta_cap'       => true,
        'supports'           => [ 'title' ],
    ];
    register_post_type( 'xinvoice', $args );
}
add_action( 'init', 'xinvoice_register_invoice_cpt' );

// =============================================================================
// 2. CARGA DE ESTILOS (CSS) Y SCRIPTS (JS)
// =============================================================================
function xinvoice_enqueue_admin_assets($hook_suffix) {
    $screen = get_current_screen();
    if ( $screen && 'xinvoice' === $screen->post_type ) {
        wp_enqueue_style( 'xinvoice-admin-style', plugin_dir_url( __FILE__ ) . 'admin/css/admin-style.css', [], '1.0.6' );
        if ( 'post.php' === $hook_suffix || 'post-new.php' === $hook_suffix ) {
            wp_enqueue_script('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', [], '2.5.1', true);
            wp_enqueue_script('html2canvas', 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js', [], '1.4.1', true);
            wp_enqueue_script('xinvoice-admin-script', plugin_dir_url( __FILE__ ) . 'admin/js/admin-scripts.js', ['jquery', 'jspdf', 'html2canvas'], '1.0.6', true);
            
            global $post;
            $invoice_items = get_post_meta($post->ID, '_invoice_items', true) ?: [];
            $company_options = get_option('xinvoice_options', []);
            wp_localize_script( 'xinvoice-admin-script', 'xinvoice_data', [
                'items'           => $invoice_items,
                'logo_url'        => $company_options['logo_url'] ?? '',
                'company_name'    => $company_options['company_name'] ?? '',
                'company_details' => $company_options['company_details'] ?? '',
                'enable_tax'      => $company_options['enable_tax'] ?? 'off',
            ]);
        }
    }
    if ( 'facturas_page_xinvoice-settings' === $hook_suffix ) {
        wp_enqueue_media();
        wp_enqueue_script( 'xinvoice-media-uploader', plugin_dir_url( __FILE__ ) . 'admin/js/media-uploader.js', ['jquery'], '1.0.6', true );
    }
}
add_action( 'admin_enqueue_scripts', 'xinvoice_enqueue_admin_assets' );

// =============================================================================
// 3. CREACIÓN DE META BOXES
// =============================================================================
function xinvoice_add_meta_boxes() {
    add_meta_box( 'xinvoice_details_meta_box', __( 'Detalles de la Factura', 'xinvoice' ), 'xinvoice_render_invoice_meta_box', 'xinvoice', 'normal', 'high' );
    add_meta_box( 'xinvoice_status_meta_box', __( 'Estado de la Factura', 'xinvoice' ), 'xinvoice_render_status_meta_box', 'xinvoice', 'side', 'high' );
}
add_action( 'add_meta_boxes', 'xinvoice_add_meta_boxes' );

function xinvoice_render_invoice_meta_box( $post ) {
    wp_nonce_field( 'xinvoice_save_invoice_data', 'xinvoice_meta_box_nonce' );
    $is_published = in_array(get_post_status( $post->ID ), ['publish', 'private']);
    $button_text = $is_published ? __( 'Actualizar Factura', 'xinvoice' ) : __( 'Guardar Factura', 'xinvoice' );
    $client_name = get_post_meta($post->ID, '_client_name', true);
    $client_email = get_post_meta($post->ID, '_client_email', true);
    $invoice_date = get_post_meta($post->ID, '_invoice_date', true) ?: date('Y-m-d');
    $invoice_due_date = get_post_meta($post->ID, '_invoice_due_date', true);
    $saved_tax_rate = get_post_meta($post->ID, '_tax_rate', true);
    if ( '' === $saved_tax_rate && ! is_numeric($saved_tax_rate) ) {
        $global_options = get_option('xinvoice_options');
        $tax_rate = $global_options['default_tax_rate'] ?? '21';
    } else { $tax_rate = $saved_tax_rate; }
    ?>
    <div class="xinvoice-form-section">
        <div class="xinvoice-form-grid">
            <div>
                <h3><?php _e( 'Cliente', 'xinvoice' ); ?></h3>
                <label for="client_name"><?php _e( 'Nombre del Cliente', 'xinvoice' ); ?></label>
                <input type="text" id="client_name" name="client_name" class="regular-text" value="<?php echo esc_attr($client_name); ?>">
                <label for="client_email"><?php _e( 'Email del Cliente', 'xinvoice' ); ?></label>
                <input type="email" id="client_email" name="client_email" class="regular-text" value="<?php echo esc_attr($client_email); ?>">
            </div>
            <div>
                <h3><?php _e( 'Detalles', 'xinvoice' ); ?></h3>
                <label for="invoice_date"><?php _e( 'Fecha de Emisión', 'xinvoice' ); ?></label>
                <input type="date" id="invoice_date" name="invoice_date" class="regular-text" value="<?php echo esc_attr($invoice_date); ?>">
                <label for="invoice_due_date"><?php _e( 'Fecha de Vencimiento', 'xinvoice' ); ?></label>
                <input type="date" id="invoice_due_date" name="invoice_due_date" class="regular-text" value="<?php echo esc_attr($invoice_due_date); ?>">
            </div>
        </div>
    </div>
    <div class="xinvoice-form-section">
        <h3><?php _e( 'Conceptos', 'xinvoice' ); ?></h3>
        <table class="wp-list-table widefat fixed striped" id="invoice-items-table">
            <thead><tr><th style="width: 50%;"><?php _e( 'Descripción', 'xinvoice' ); ?></th><th><?php _e( 'Cantidad', 'xinvoice' ); ?></th><th><?php _e( 'Precio', 'xinvoice' ); ?></th><th><?php _e( 'Total', 'xinvoice' ); ?></th><th style="width: 5%;"></th></tr></thead>
            <tbody id="invoice-item-rows"></tbody>
        </table>
        <button type="button" class="button" id="add-invoice-item"><?php _e( 'Añadir concepto', 'xinvoice' ); ?></button>
    </div>
    <div class="xinvoice-totals-section">
        <div class="xinvoice-totals-grid">
            <div class="xinvoice-totals-labels">
                <p><?php _e( 'Subtotal', 'xinvoice' ); ?></p>
                <p class="xinvoice-tax-row"><?php _e( 'Impuestos (%)', 'xinvoice' ); ?></p>
                <p class="xinvoice-grand-total-label"><?php _e( 'Total', 'xinvoice' ); ?></p>
            </div>
            <div class="xinvoice-totals-values">
                <p><span id="invoice-subtotal">0.00</span></p>
                <p class="xinvoice-tax-row"><input type="number" id="invoice-tax-rate" name="tax_rate" placeholder="21" min="0" value="<?php echo esc_attr( $tax_rate ); ?>"></p>
                <p class="xinvoice-grand-total-value"><span id="invoice-grand-total">0.00</span></p>
            </div>
        </div>
    </div>
    <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center;">
        <button type="button" id="xinvoice-download-pdf" class="button button-secondary"><?php _e( 'Descargar PDF', 'xinvoice' ); ?></button>
        <input type="submit" name="publish" id="publish" class="button button-primary button-large" value="<?php echo esc_attr( $button_text ); ?>">
    </div>
    <div id="xinvoice-pdf-render-wrapper" style="position: absolute; left: -9999px; top: auto; width: 800px; background-color: #fff;"></div>
    <?php
}

function xinvoice_render_status_meta_box( $post ) {
    wp_nonce_field( 'xinvoice_save_status_data', 'xinvoice_status_nonce' );
    $current_status = get_post_meta( $post->ID, '_invoice_status', true ) ?: 'draft';
    ?>
    <select name="invoice_status" style="width:100%;">
        <option value="draft" <?php selected( $current_status, 'draft' ); ?>><?php _e( 'Borrador', 'xinvoice' ); ?></option>
        <option value="sent" <?php selected( $current_status, 'sent' ); ?>><?php _e( 'Enviada', 'xinvoice' ); ?></option>
        <option value="paid" <?php selected( $current_status, 'paid' ); ?>><?php _e( 'Pagada', 'xinvoice' ); ?></option>
        <option value="overdue" <?php selected( $current_status, 'overdue' ); ?>><?php _e( 'Vencida', 'xinvoice' ); ?></option>
        <option value="void" <?php selected( $current_status, 'void' ); ?>><?php _e( 'Anulada', 'xinvoice' ); ?></option>
    </select>
    <?php
}

// =============================================================================
// 4. LÓGICA PARA GUARDAR LOS DATOS
// =============================================================================
function xinvoice_save_invoice_meta_data( $post_id ) {
    if ( ! isset( $_POST['xinvoice_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['xinvoice_meta_box_nonce'], 'xinvoice_save_invoice_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    if ( ! isset($_POST['post_type']) || 'xinvoice' !== $_POST['post_type'] ) return;

    if ( !get_post_meta($post_id, '_invoice_number', true) ) {
        $last_number = get_option('xinvoice_invoice_counter', 0);
        $new_number = $last_number + 1;
        $formatted_number = 'FAC' . str_pad($new_number, 4, '0', STR_PAD_LEFT);
        update_post_meta($post_id, '_invoice_number', $new_number);
        update_option('xinvoice_invoice_counter', $new_number);
        remove_action('save_post', 'xinvoice_save_invoice_meta_data');
        wp_update_post(['ID' => $post_id, 'post_title' => $formatted_number]);
        add_action('save_post', 'xinvoice_save_invoice_meta_data');
    }

    $fields_to_save = ['client_name', 'client_email', 'invoice_date', 'invoice_due_date', 'tax_rate'];
    foreach ($fields_to_save as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
    if ( isset( $_POST['invoice_status'] ) && isset( $_POST['xinvoice_status_nonce'] ) && wp_verify_nonce( $_POST['xinvoice_status_nonce'], 'xinvoice_save_status_data' ) ) {
        $valid_statuses = ['draft', 'sent', 'paid', 'overdue', 'void'];
        $status_to_save = sanitize_text_field( $_POST['invoice_status'] );
        if ( in_array( $status_to_save, $valid_statuses ) ) {
            update_post_meta( $post_id, '_invoice_status', $status_to_save );
        }
    }
    $invoice_items = isset( $_POST['invoice_items'] ) ? (array) $_POST['invoice_items'] : [];
    update_post_meta($post_id, '_invoice_items', array_values($invoice_items));
    $subtotal = 0;
    foreach($invoice_items as $item) { $subtotal += (floatval($item['quantity'] ?? 0) * floatval($item['price'] ?? 0)); }
    $tax_rate = floatval($_POST['tax_rate'] ?? 0);
    $grand_total = $subtotal * (1 + ($tax_rate / 100));
    update_post_meta($post_id, '_grand_total', $grand_total);
}
add_action( 'save_post', 'xinvoice_save_invoice_meta_data' );

// =============================================================================
// 5. COLUMNAS PERSONALIZADAS
// =============================================================================
function xinvoice_set_custom_edit_invoice_columns($columns) {
    return ['cb' => $columns['cb'], 'title' => __( 'Factura', 'xinvoice' ), 'client_name' => __( 'Cliente', 'xinvoice' ), 'invoice_status'=> __( 'Estado', 'xinvoice' ), 'invoice_date' => __( 'Fecha', 'xinvoice' ), 'grand_total' => __( 'Total', 'xinvoice' ), 'date' => __( 'Publicada', 'xinvoice' )];
}
add_filter( 'manage_xinvoice_posts_columns', 'xinvoice_set_custom_edit_invoice_columns' );

function xinvoice_custom_invoice_column( $column, $post_id ) {
    switch ( $column ) {
        case 'client_name': echo esc_html( get_post_meta( $post_id, '_client_name', true ) ); break;
        case 'invoice_status':
            $status = get_post_meta( $post_id, '_invoice_status', true ) ?: 'draft';
            $status_labels = [ 'draft' => __('Borrador', 'xinvoice'), 'sent' => __('Enviada', 'xinvoice'), 'paid' => __('Pagada', 'xinvoice'), 'overdue' => __('Vencida', 'xinvoice'), 'void' => __('Anulada', 'xinvoice') ];
            echo '<span class="status-pill status-' . esc_attr($status) . '">' . esc_html($status_labels[$status]) . '</span>';
            break;
        case 'invoice_date': echo esc_html( get_post_meta( $post_id, '_invoice_date', true ) ); break;
        case 'grand_total':
            $total = get_post_meta( $post_id, '_grand_total', true );
            echo '<strong>' . esc_html( number_format_i18n( floatval($total), 2 ) ) . ' €</strong>';
            echo '<div class="row-actions"><span class="edit"><a href="' . get_edit_post_link($post_id) . '">' . __('Editar', 'xinvoice') . '</a> | </span><span class="trash"><a href="' . get_delete_post_link($post_id) . '" class="submitdelete">' . __('Mover a la papelera', 'xinvoice') . '</a></span></div>';
            break;
    }
}
add_action( 'manage_xinvoice_posts_custom_column', 'xinvoice_custom_invoice_column', 10, 2 );

// =============================================================================
// 6. PÁGINA DE AJUSTES DEL PLUGIN
// =============================================================================
function xinvoice_add_settings_page() {
    add_submenu_page( 'edit.php?post_type=xinvoice', __( 'Ajustes de xInvoice', 'xinvoice' ), __( 'Ajustes', 'xinvoice' ), 'manage_options', 'xinvoice-settings', 'xinvoice_settings_page_html' );
}
add_action( 'admin_menu', 'xinvoice_add_settings_page' );

function xinvoice_settings_page_html() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php settings_fields( 'xinvoice_settings' ); do_settings_sections( 'xinvoice_settings' ); submit_button( __( 'Guardar Cambios', 'xinvoice' ) ); ?>
        </form>
    </div>
    <?php
}

function xinvoice_settings_init() {
    register_setting( 'xinvoice_settings', 'xinvoice_options' );
    add_settings_section( 'xinvoice_company_section', __( 'Los Datos de tu Empresa', 'xinvoice' ), 'xinvoice_company_section_callback', 'xinvoice_settings' );
    add_settings_field( 'xinvoice_logo', __( 'Logo de la Empresa', 'xinvoice' ), 'xinvoice_logo_field_html', 'xinvoice_settings', 'xinvoice_company_section' );
    add_settings_field( 'xinvoice_company_name', __( 'Nombre de la Empresa', 'xinvoice' ), 'xinvoice_company_name_field_html', 'xinvoice_settings', 'xinvoice_company_section' );
    add_settings_field( 'xinvoice_company_details', __( 'Dirección y Contacto', 'xinvoice' ), 'xinvoice_company_details_field_html', 'xinvoice_settings', 'xinvoice_company_section' );
    add_settings_field( 'xinvoice_enable_tax', __( 'Activar Impuestos', 'xinvoice' ), 'xinvoice_enable_tax_field_html', 'xinvoice_settings', 'xinvoice_company_section' );
    add_settings_field( 'xinvoice_default_tax_rate', __( 'Impuesto por Defecto (%)', 'xinvoice' ), 'xinvoice_default_tax_rate_field_html', 'xinvoice_settings', 'xinvoice_company_section' );
}
add_action( 'admin_init', 'xinvoice_settings_init' );

function xinvoice_company_section_callback() {
    echo '<p>' . __( 'Introduce los datos que aparecerán como emisor en tus facturas.', 'xinvoice' ) . '</p>';
}

function xinvoice_logo_field_html() {
    $options = get_option( 'xinvoice_options' ); $logo_url = $options['logo_url'] ?? '';
    ?>
    <div class="xinvoice-logo-uploader">
        <div class="logo-preview"><?php if ( $logo_url ) : ?><img src="<?php echo esc_url( $logo_url ); ?>" style="max-width: 200px; height: auto;"><?php endif; ?></div>
        <input type="hidden" name="xinvoice_options[logo_url]" id="xinvoice_logo_url" value="<?php echo esc_attr( $logo_url ); ?>">
        <button type="button" class="button" id="upload_logo_button"><?php _e( 'Subir o Elegir Logo', 'xinvoice' ); ?></button>
        <button type="button" class="button" id="remove_logo_button" style="<?php echo ( $logo_url ? '' : 'display:none;' ); ?>"><?php _e( 'Quitar Logo', 'xinvoice' ); ?></button>
    </div>
    <?php
}

function xinvoice_company_name_field_html() {
    $options = get_option( 'xinvoice_options' );
    ?><input type="text" name="xinvoice_options[company_name]" value="<?php echo esc_attr( $options['company_name'] ?? '' ); ?>" class="regular-text"><?php
}

function xinvoice_company_details_field_html() {
    $options = get_option( 'xinvoice_options' );
    ?><textarea name="xinvoice_options[company_details]" rows="5" cols="50" class="large-text"><?php echo esc_textarea( $options['company_details'] ?? '' ); ?></textarea><p class="description"><?php _e( 'Introduce la dirección de tu empresa, email, teléfono, etc. Uno por línea.', 'xinvoice' ); ?></p><?php
}

function xinvoice_enable_tax_field_html() {
    $options = get_option( 'xinvoice_options' );
    ?><input type="checkbox" name="xinvoice_options[enable_tax]" <?php checked( $options['enable_tax'] ?? '', 'on' ); ?>><label> <?php _e( 'Marcar para habilitar el cálculo de impuestos en las facturas.', 'xinvoice' ); ?></label><?php
}

function xinvoice_default_tax_rate_field_html() {
    $options = get_option( 'xinvoice_options' );
    ?><input type="number" name="xinvoice_options[default_tax_rate]" value="<?php echo esc_attr( $options['default_tax_rate'] ?? '21' ); ?>" class="small-text"><p class="description"><?php _e( 'Este valor se usará por defecto en las nuevas facturas.', 'xinvoice' ); ?></p><?php
}

// =============================================================================
// 7. TAREA AUTOMÁTICA PARA FACTURAS VENCIDAS (WP-CRON)
// =============================================================================
function xinvoice_check_for_overdue_invoices() {
    $today = new DateTime(); $today->setTime(0, 0, 0);
    $args = [ 'post_type' => 'xinvoice', 'posts_per_page' => -1, 'meta_query' => [ [ 'key' => '_invoice_status', 'value' => 'sent', 'compare' => '=', ], ], ];
    $overdue_query = new WP_Query($args);
    if ($overdue_query->have_posts()) {
        while ($overdue_query->have_posts()) {
            $overdue_query->the_post();
            $invoice_id = get_the_ID();
            $due_date_str = get_post_meta($invoice_id, '_invoice_due_date', true);
            if ( ! empty($due_date_str) ) {
                $due_date = new DateTime($due_date_str); $due_date->setTime(0, 0, 0);
                if ($due_date < $today) { update_post_meta($invoice_id, '_invoice_status', 'overdue'); }
            }
        }
    }
    wp_reset_postdata();
}
add_action( 'xinvoice_daily_overdue_check', 'xinvoice_check_for_overdue_invoices' );

function xinvoice_schedule_cron_jobs() {
    if ( ! wp_next_scheduled( 'xinvoice_daily_overdue_check' ) ) {
        wp_schedule_event( time(), 'daily', 'xinvoice_daily_overdue_check' );
    }
}
register_activation_hook( __FILE__, 'xinvoice_schedule_cron_jobs' );

function xinvoice_unschedule_cron_jobs() {
    wp_clear_scheduled_hook( 'xinvoice_daily_overdue_check' );
}
register_deactivation_hook( __FILE__, 'xinvoice_unschedule_cron_jobs' );

// =============================================================================
// 8. LLAMADO A LA ACCIÓN PARA LA VERSIÓN PREMIUM
// =============================================================================

/**
 * Muestra un aviso para la versión premium en la página de listado de facturas.
 */
function xinvoice_show_premium_upsell_notice() {
    // Solo mostrar el aviso a los administradores
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // Comprobar si el usuario ya ha cerrado este aviso anteriormente
    if ( get_user_meta( get_current_user_id(), 'xinvoice_premium_notice_dismissed', true ) ) {
        return;
    }

    // Comprobar que estamos en la página correcta (la lista de facturas)
    $screen = get_current_screen();
    if ( !$screen || 'edit-xinvoice' !== $screen->id ) {
        return;
    }
    
    // Generamos una URL para que el usuario pueda cerrar el aviso de forma segura
    $dismiss_url = wp_nonce_url( add_query_arg( 'xinvoice_dismiss_notice', 'true' ), 'xinvoice_dismiss_notice_nonce', '_xinvoice_nonce' );
    ?>
    <div class="notice notice-info is-dismissible" data-dismiss-url="<?php echo esc_url( $dismiss_url ); ?>">
        <p>
            <?php _e( 'Estás usando la versión gratuita de xInvoice.', 'xinvoice' ); ?> 
            <?php _e( 'Pásate a Premium para desbloquear funcionalidades increíbles:', 'xinvoice' ); ?>
        </p>
        <ul style="list-style:-moz-initial; margin-left:20px;">
            <li><?php _e( 'Envío automático de facturas por email.', 'xinvoice' ); ?></li>
            <li><?php _e( 'Integración con pasarelas de pago (Stripe y PayPal).', 'xinvoice' ); ?></li>
            <li><?php _e( 'Creación de facturas recurrentes para tus clientes.', 'xinvoice' ); ?></li>
            <li><?php _e( 'Guarda y gestiona clientes para crear facturas más rápido.', 'xinvoice' ); ?></li>
            <li><?php _e( 'Informes y estadísticas avanzadas.', 'xinvoice' ); ?></li>
        </ul>
        <p>
            <a href="https://arrobapunto.com/plugins" class="button button-primary" target="_blank"><?php _e( 'Descubre la Versión Premium', 'xinvoice' ); ?></a>
            <a href="<?php echo esc_url( $dismiss_url ); ?>" class="button button-secondary"><?php _e( 'Cerrar aviso', 'xinvoice' ); ?></a>
        </p>
    </div>
    <?php
}
add_action( 'admin_notices', 'xinvoice_show_premium_upsell_notice' );

/**
 * Gestiona el cierre del aviso premium.
 */
function xinvoice_dismiss_premium_notice_handler() {
    if ( isset( $_GET['xinvoice_dismiss_notice'] ) && isset( $_GET['_xinvoice_nonce'] ) ) {
        if ( ! wp_verify_nonce( $_GET['_xinvoice_nonce'], 'xinvoice_dismiss_notice_nonce' ) ) {
            wp_die( __( 'Error de seguridad.', 'xinvoice' ) );
        }
        // Guardamos en la base de datos que este usuario ha cerrado el aviso
        update_user_meta( get_current_user_id(), 'xinvoice_premium_notice_dismissed', 'true' );
    }
}
add_action( 'admin_init', 'xinvoice_dismiss_premium_notice_handler' );

// =============================================================================
// 9. PANTALLA DE BIENVENIDA AL ACTIVAR EL PLUGIN
// =============================================================================

/**
 * Guarda una opción temporal para redirigir al usuario tras la activación.
 */
function xinvoice_activation_redirect() {
    // Establecemos un "transient" que dura 30 segundos.
    set_transient( '_xinvoice_welcome_redirect', true, 30 );
}
register_activation_hook( __FILE__, 'xinvoice_activation_redirect' );

/**
 * Redirige a la página de bienvenida si la opción temporal existe.
 */
function xinvoice_welcome_screen_redirect() {
    // Comprueba si nuestro transient existe
    if ( get_transient( '_xinvoice_welcome_redirect' ) ) {
        // Bórralo para que no se redirija de nuevo
        delete_transient( '_xinvoice_welcome_redirect' );

        // Redirige a nuestra página de bienvenida
        wp_safe_redirect( admin_url( 'index.php?page=xinvoice-welcome' ) );
        exit;
    }
}
add_action( 'admin_init', 'xinvoice_welcome_screen_redirect' );

/**
 * Registra la página de bienvenida (sin añadirla al menú).
 */
function xinvoice_register_welcome_page() {
    add_dashboard_page(
        __( 'Bienvenido a xInvoice', 'xinvoice' ), // Título de la página
        __( 'Bienvenido a xInvoice', 'xinvoice' ), // Título del navegador
        'read',                                    // Capacidad mínima
        'xinvoice-welcome',                        // Slug de la página
        'xinvoice_welcome_page_html',              // Función que renderiza el HTML
        ['parent' => null]                         // Oculta del menú
    );
}
add_action( 'admin_menu', 'xinvoice_register_welcome_page' );

/**
 * Renderiza el HTML de la página de bienvenida.
 */
function xinvoice_welcome_page_html() {
    ?>
    <div class="wrap" style="text-align: center; padding-top: 50px;">
        <img src="<?php echo esc_url( plugin_dir_url( __FILE__ ) . 'assets/images/welcome-banner.png' ); ?>" alt="Bienvenido a xInvoice" style="max-width: 600px; margin-bottom: 30px;">
        
        <h1 style="font-size: 2.5em; margin-bottom: 20px;"><?php _e( '¡Gracias por instalar xInvoice!', 'xinvoice' ); ?></h1>
        
        <p style="font-size: 1.2em; max-width: 650px; margin: 0 auto 30px;">
            <?php _e( 'Estás a un paso de gestionar tus facturas de la forma más sencilla y elegante. Haz clic en el botón de abajo para empezar a crear tu primera factura.', 'xinvoice' ); ?>
        </p>
        
        <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=xinvoice' ) ); ?>" class="button button-primary button-hero">
            <?php _e( 'Crear mi Primera Factura', 'xinvoice' ); ?>
        </a>
    </div>
    <?php
}